!function(){
  var d3 = {version: "3.4.10"}; // semver
